Walkthrough - https://www.cryptobullsh.com/2021/08/intro-to-ravencoin-development/

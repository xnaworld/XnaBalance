# RavenCoin
RavenCoin Library for C#

Right now it only generates random Ravencoin addresses. Good for making a vanity address, though I would not put anything valuable into it!! 
It's not strongly encrypted, and you shouldn't trust random code on the internet without verifying it yourself. This is just for fun,
and for learning about the Raven Blockchain. Hope it helps someone!

I also have a copy of this in PHP on my github if that's your language of choice.
